SELECT
  'NO_USABLE_PATENT_CITATION_FROM_GRANT_TEXT' AS input_cited_country,
  'NO_USABLE_PATENT_CITATION' AS input_cited_cpc4,
  a.appln_auth AS output_citing_country,
  COALESCE(cpc_out.cpc4, 'NO_CPC') AS output_citing_cpc4,
  SUM(COALESCE(1.0 / cpc_out.cpc_count, 1.0)) AS io_weight
FROM tls201_appln a
LEFT JOIN
(
  SELECT DISTINCT
    a2.appln_id
  FROM tls201_appln a2
  JOIN tls211_pat_publn p2
    ON a2.appln_id = p2.appln_id
   AND p2.publn_first_grant = 'Y'
  JOIN tls212_citation c2
    ON p2.pat_publn_id = c2.pat_publn_id
  WHERE a2.appln_filing_year = 2019
    AND a2.granted = 'Y'
    AND a2.appln_auth IS NOT NULL
    AND a2.appln_auth <> ''
    AND c2.pat_citn_seq_nr > 0
    AND (
      c2.cited_appln_id > 0
      OR c2.cited_pat_publn_id > 0
    )
) has_cite
  ON a.appln_id = has_cite.appln_id
LEFT JOIN
(
  SELECT
    x.docdb_family_id,
    x.cpc4,
    cc.cpc_count
  FROM
  (
    SELECT DISTINCT
      docdb_family_id,
      LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
    FROM tls225_docdb_fam_cpc
    WHERE cpc_class_symbol IS NOT NULL
      AND cpc_class_symbol <> ''
  ) x
  JOIN
  (
    SELECT
      y.docdb_family_id,
      COUNT(DISTINCT y.cpc4) AS cpc_count
    FROM
    (
      SELECT DISTINCT
        docdb_family_id,
        LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
      FROM tls225_docdb_fam_cpc
      WHERE cpc_class_symbol IS NOT NULL
        AND cpc_class_symbol <> ''
    ) y
    GROUP BY y.docdb_family_id
  ) cc
    ON x.docdb_family_id = cc.docdb_family_id
) cpc_out
  ON a.docdb_family_id = cpc_out.docdb_family_id
WHERE a.appln_filing_year = 2019
  AND a.granted = 'Y'
  AND a.appln_auth IS NOT NULL
  AND a.appln_auth <> ''
  AND has_cite.appln_id IS NULL
GROUP BY
  a.appln_auth,
  COALESCE(cpc_out.cpc4, 'NO_CPC')
ORDER BY
  a.appln_auth,
  COALESCE(cpc_out.cpc4, 'NO_CPC')
