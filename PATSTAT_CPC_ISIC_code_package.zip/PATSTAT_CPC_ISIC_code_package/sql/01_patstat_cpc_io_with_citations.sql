SELECT
  z.input_cited_country,
  z.input_cited_cpc4,
  z.output_citing_country,
  z.output_citing_cpc4,
  SUM(z.io_weight) AS io_weight
FROM
(
  SELECT
    pc.input_cited_country,
    COALESCE(cpc_in.cpc4, 'NO_CPC') AS input_cited_cpc4,
    pc.output_citing_country,
    COALESCE(cpc_out.cpc4, 'NO_CPC') AS output_citing_cpc4,
    (1.0 / od.d)
      * COALESCE(1.0 / cpc_in.cpc_count, 1.0)
      * COALESCE(1.0 / cpc_out.cpc_count, 1.0) AS io_weight
  FROM
  (
    SELECT DISTINCT
      a.appln_id AS citing_appln_id,
      a.docdb_family_id AS citing_docdb_family_id,
      a.appln_auth AS output_citing_country,
      CASE
        WHEN ca1.appln_id IS NOT NULL THEN ca1.appln_id
        WHEN ca2.appln_id IS NOT NULL THEN ca2.appln_id
        ELSE NULL
      END AS cited_appln_id,
      CASE
        WHEN ca1.docdb_family_id IS NOT NULL THEN ca1.docdb_family_id
        WHEN ca2.docdb_family_id IS NOT NULL THEN ca2.docdb_family_id
        ELSE NULL
      END AS cited_docdb_family_id,
      CASE
        WHEN ca1.appln_auth IS NOT NULL THEN ca1.appln_auth
        WHEN ca2.appln_auth IS NOT NULL THEN ca2.appln_auth
        ELSE 'UNKNOWN'
      END AS input_cited_country,
      CASE
        WHEN c.cited_appln_id > 0 THEN 'A' + CAST(c.cited_appln_id AS VARCHAR(30))
        ELSE 'P' + CAST(c.cited_pat_publn_id AS VARCHAR(30))
      END AS cited_key
    FROM tls201_appln a
    JOIN tls211_pat_publn p
      ON a.appln_id = p.appln_id
     AND p.publn_first_grant = 'Y'
    JOIN tls212_citation c
      ON p.pat_publn_id = c.pat_publn_id
    LEFT JOIN tls201_appln ca1
      ON c.cited_appln_id = ca1.appln_id
    LEFT JOIN tls211_pat_publn cp
      ON c.cited_pat_publn_id = cp.pat_publn_id
    LEFT JOIN tls201_appln ca2
      ON cp.appln_id = ca2.appln_id
    WHERE a.appln_filing_year = 2019
      AND a.granted = 'Y'
      AND a.appln_auth IS NOT NULL
      AND a.appln_auth <> ''
      AND c.pat_citn_seq_nr > 0
      AND (
        c.cited_appln_id > 0
        OR c.cited_pat_publn_id > 0
      )
  ) pc
  JOIN
  (
    SELECT
      q.citing_appln_id,
      COUNT(DISTINCT q.cited_key) AS d
    FROM
    (
      SELECT DISTINCT
        a.appln_id AS citing_appln_id,
        CASE
          WHEN c.cited_appln_id > 0 THEN 'A' + CAST(c.cited_appln_id AS VARCHAR(30))
          ELSE 'P' + CAST(c.cited_pat_publn_id AS VARCHAR(30))
        END AS cited_key
      FROM tls201_appln a
      JOIN tls211_pat_publn p
        ON a.appln_id = p.appln_id
       AND p.publn_first_grant = 'Y'
      JOIN tls212_citation c
        ON p.pat_publn_id = c.pat_publn_id
      WHERE a.appln_filing_year = 2019
        AND a.granted = 'Y'
        AND a.appln_auth IS NOT NULL
        AND a.appln_auth <> ''
        AND c.pat_citn_seq_nr > 0
        AND (
          c.cited_appln_id > 0
          OR c.cited_pat_publn_id > 0
        )
    ) q
    GROUP BY q.citing_appln_id
  ) od
    ON pc.citing_appln_id = od.citing_appln_id
  LEFT JOIN
  (
    SELECT
      x.docdb_family_id,
      x.cpc4,
      cc.cpc_count
    FROM
    (
      SELECT DISTINCT
        docdb_family_id,
        LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
      FROM tls225_docdb_fam_cpc
      WHERE cpc_class_symbol IS NOT NULL
        AND cpc_class_symbol <> ''
    ) x
    JOIN
    (
      SELECT
        y.docdb_family_id,
        COUNT(DISTINCT y.cpc4) AS cpc_count
      FROM
      (
        SELECT DISTINCT
          docdb_family_id,
          LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
        FROM tls225_docdb_fam_cpc
        WHERE cpc_class_symbol IS NOT NULL
          AND cpc_class_symbol <> ''
      ) y
      GROUP BY y.docdb_family_id
    ) cc
      ON x.docdb_family_id = cc.docdb_family_id
  ) cpc_out
    ON pc.citing_docdb_family_id = cpc_out.docdb_family_id
  LEFT JOIN
  (
    SELECT
      x.docdb_family_id,
      x.cpc4,
      cc.cpc_count
    FROM
    (
      SELECT DISTINCT
        docdb_family_id,
        LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
      FROM tls225_docdb_fam_cpc
      WHERE cpc_class_symbol IS NOT NULL
        AND cpc_class_symbol <> ''
    ) x
    JOIN
    (
      SELECT
        y.docdb_family_id,
        COUNT(DISTINCT y.cpc4) AS cpc_count
      FROM
      (
        SELECT DISTINCT
          docdb_family_id,
          LEFT(LTRIM(RTRIM(CAST(cpc_class_symbol AS VARCHAR(30)))), 4) AS cpc4
        FROM tls225_docdb_fam_cpc
        WHERE cpc_class_symbol IS NOT NULL
          AND cpc_class_symbol <> ''
      ) y
      GROUP BY y.docdb_family_id
    ) cc
      ON x.docdb_family_id = cc.docdb_family_id
  ) cpc_in
    ON pc.cited_docdb_family_id = cpc_in.docdb_family_id
) z
GROUP BY
  z.input_cited_country,
  z.input_cited_cpc4,
  z.output_citing_country,
  z.output_citing_cpc4
ORDER BY
  z.input_cited_country,
  z.input_cited_cpc4,
  z.output_citing_country,
  z.output_citing_cpc4
