SELECT TOP 5
  docdb_family_id,
  cpc_class_symbol
FROM tls225_docdb_fam_cpc
