# PATSTAT CPC→ISIC Migration Code Package

This package is for regenerating the PATSTAT-only 2019 granted patent country-industry IO table using the previously generated CPC→ISIC mapping file, instead of PATSTAT NACE2.

## Why this package is needed

The current country-industry output used PATSTAT `tls229_appln_nace2`.  
The teacher requested using the previous CPC→ISIC mapping file instead.

The previous zip `patent_isic_io_results_2019.zip` contains:

- `cpc_isic_mapping_draft.csv`

This file is reused as the CPC 4-digit subclass → ISIC 2-digit mapping table.

## What still needs to be exported from PATSTAT

The already generated country-level IO table cannot be directly converted to CPC→ISIC, because it has no CPC or application-level information.

Please run these SQL files in PATSTAT Online:

1. `sql/00_smoke_test_cpc_family.sql`
2. `sql/01_patstat_cpc_io_with_citations.sql`
3. `sql/02_patstat_cpc_io_no_usable_citations.sql`

Download the two formal outputs as CSV.

Recommended filenames:

- `PATSTAT_CPC_with_citations.csv`
- `PATSTAT_CPC_no_usable_citations.csv`

## Build final CPC→ISIC country-industry IO

Put these files in a folder:

- `PATSTAT_CPC_with_citations.csv`
- `PATSTAT_CPC_no_usable_citations.csv`
- `cpc_isic_mapping_draft.csv`

Then run:

```bash
python python/build_cpc_isic_io.py --input-dir ./data --output-dir ./output
```

Main output:

- `PATSTAT_2019_granted_country_industry_IO_CPC_ISIC_long.csv`

## Final fields

- `input_cited_country`
- `input_cited_isic`
- `output_citing_country`
- `output_citing_isic`
- `io_weight`

## Notes

- CPC is taken from PATSTAT family-level CPC table `tls225_docdb_fam_cpc`.
- If `tls225_docdb_fam_cpc` is not available in the interface, use `tls224_appln_cpc` fallback with minor SQL modification.
- `NO_CPC` means a PATSTAT application/family has no usable CPC code in the query.
- `NO_ISIC` means the CPC code was not found in the CPC→ISIC mapping table.
